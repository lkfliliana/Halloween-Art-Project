import turtle




wn = turtle.Screen()
wn.mainloop()